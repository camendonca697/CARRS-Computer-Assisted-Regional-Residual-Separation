% CARRS - Computed Assisted Regional-Residual Separation
%
% prog01 sets a noise-level to the time series that is kept in evaluating
%        the regularized derivatives along the rows and columns of the grid
%
%        obs: this program compares the regularized derivatives by using
%             the automatic determination according to the discrepancy 
%             principle with results from pre-specifying a noise-level to the data set.
%             This stage is necessary to verify if results are equivalent
%             to then fixing a well suited noise-level. Otherwise distinct 
%             regularizing parameters may be set as the rows and columns are
%             processed individually, not converging in cases where the automatic 
%             tunning fails.
%             As a rule, smoother derivatives are determined if prescribing higher
%             noise-levels for the data.
%
%             
%             Developed with:  
%             MATLAB 8.5 2015 version, 
%             64-bit Windows 11 PC (8 GB RAM, 2.80 GHz Intel Core processor)   
%
%--------------------------------------------------
%
% a) grid data input
clear
load bgr.grd -ascii
load y0.grd -ascii
load x0.grd -ascii
gz=bgr+45.7; % this DC level correction is discussed in the paper
dd=0.75; % grid spacing for this data set (km)
% 
% b) noise-levels to evaluate 1st and 2nd derivatives
sgm1=0.01;
sgm2=0.00001;
%
% parameters to format pictures and input to followinb programs
cca=50; % anomaly range for graphics
par=[sgm1 0 0 sgm2 0 0 cca dd 0.1 0.1]';
save par.res par -ascii
xI=x0(1);xF=x0(end);
%
% Comparison of derivatives along the columns of the grid data
ny=length(y0);
figure
for iy=50:50:ny
    aR1 = rdiff(gz(:,iy),dd,'tikhonov',sgm1);aR2 = rdiff(aR1,dd,'tikhonov',sgm2);
    bR1 = rdiff(gz(:,iy),dd,'tikhonov');bR2 = rdiff(bR1,dd,'tikhonov');
    subplot(211)
    plot(x0,bR1,'-k',x0,aR1,'-r');
    legend('automatic',['{\sigma_1} =' num2str(sgm1)]);
    ylabel('1st derivative')
    %
    subplot(212)
    plot(x0,bR2,'-k',x0,aR2,'-r');
    legend('automatic',['{\sigma_2} =' num2str(sgm2)]);
    ylabel('2nd derivative')
    pause(2)
end
 
save MATprog01_SetMuValues.mat