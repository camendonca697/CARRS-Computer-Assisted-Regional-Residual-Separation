% CARRS - Computed Assisted Regional-Residual Separation
%
% prog02 Evaluation of 1st and 2nd regularized derivatives
%        (it may take about ~20 minutes for the testing grid!) 
% 
% input: grid data and parameters defined at prog01
% output: grids with 1st and 2nd derivatives 
%         x-derivatives along the columns (gz1x.ees gz2x.res)
%         y-derivatives along the rows (gz1y.res gz2y.res)
%
%  based on function rdiff.m from Jakub Wagner (2022) [Thanks to him!]
% https://www.mathworks.com/matlabcentral/fileexchange/74165-regularised-numerical-differentiation
%
%
%      Developed with:  
%      MATLAB 8.5 2015 version, 
%      64-bit Windows 11 PC (8 GB RAM, 2.80 GHz Intel Core processor)   
%--------------------------------------------------
%
% a) grid data input
clear
load bgr.grd -ascii
load y0.grd -ascii
load x0.grd -ascii
gz=bgr+45.7;
%
% b) read outputs from prog01
load par.res -ascii
sgm1=par(1);
sgm2=par(4);
dd  =par(8);
%
% c) evaluation of regularized derivatives along the columns
[nx ny]=size(gz);
Gz1=zeros(nx,ny);
Gz2=zeros(nx,ny);
clc
tic
disp('Derivatives along grid columns_____')
for iy=1:ny
    aR1 = rdiff(gz(:,iy),dd,'tikhonov',sgm1);
    aR2 = rdiff(aR1,dd,'tikhonov',sgm2);
    Gz1(:,iy)=aR1;
    Gz2(:,iy)=aR2;
    fp=10;
    ff=floor(ny*fp/100);
    rg=rem(iy,ff);
    if rg == 0;disp(['----' num2str(iy/ff*fp)]);end
end
save gz1x.res Gz1 -ascii 
save gz2x.res Gz2 -ascii
toc
%
% e) evaluation of regularized derivatives along the columns
disp('Derivatives along the grid rows_____')
tic
Gz1=zeros(nx,ny);
Gz2=zeros(nx,ny);
for ix=1:nx
    aR1 = rdiff(gz(ix,:),dd,'tikhonov',sgm1);
    aR2 = rdiff(aR1,dd,'tikhonov',sgm2);
    Gz1(ix,:)=aR1;
    Gz2(ix,:)=aR2;
    fp=10;ff=floor(nx*fp/100);
    rg=rem(ix,ff);
    if rg == 0;disp(['----' num2str(ix/ff*fp)]);end
end
save gz1y.res Gz1 -ascii
save gz2y.res Gz2 -ascii
toc