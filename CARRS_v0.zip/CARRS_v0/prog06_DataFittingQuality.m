% CARRS - Computed Assisted Regional-Residual Separation
%
% prog06 Evaluate data fitting quality to the selected data points
% 
% input: selected points with low Gh (gradient) and Lh (Laplacian
%
% output: Coefficient of determination (R2) for data values and model 
%         evaluated cross-plot, histograma with respective residuals 
%         
% obs: at this point the interpreter may discard a given
%      polynomial model if data fitting it provides
%      is poor, for example with low R2
%
%      Developed with:  
%      MATLAB 8.5 2015 version, 
%      64-bit Windows 11 PC (8 GB RAM, 2.80 GHz Intel Core processor)  
%--------------------------------------------------
%
% a) grid data input
clear
load bgr.grd -ascii
load y0.grd -ascii
load x0.grd -ascii
gz=bgr+45.7;
[nx ny]=size(gz);
%
% b) read selected points with low horizontal gradient and Laplacian
load jfm.res -ascii
jFm=logical(jfm);
%
% c) preparation to call function fit
x0c=mean(x0);x0=x0-x0c;
y0c=mean(y0);y0=y0-y0c;
N=nx*ny;
JF=reshape(jFm,N,1);
dc=reshape(gz,N,1);
D0=dc(JF);
uu=reshape(repmat(x0,1,ny),N,1);
X0=uu(JF);
uu=reshape(repmat(y0',nx,1),N,1);
Y0=uu(JF);
n0=length(D0);
%
% d) LOWESS fitting to selected points
load spn.res -ascii
[xmesh, ymesh]=meshgrid(y0',x0);
[A,gof] = fit([Y0,X0],D0,'lowess','robust','Bisquare','normalize','on','Span',spn);
R0C = feval(A,xmesh,ymesh);
DC = feval(A,Y0,X0);
%
% e) cross plot and R2 in fitting the selected points
figure
subplot(121)
plot(D0,DC,'ok','MarkerSize',6,'MarkerFaceColor','w');
axis square
xlabel('Selected points (mGal)')
ylabel('Polynomial evaluated (mGal)')
axis([-40 40 -40 40])
hold on;plot([-40 40],[-40 40],'--k','Linewidth',2);hold off
R2=gof.rsquare;
cR=num2str(0.01*round(100*R2));
cR=['{R^2=}' cR];
text(-30,+30,cR);
subplot(122)
hist(D0-DC,15);axis square
ylabel('Number of points')
xlabel('Residuals to selected points (mGal)')
