% CARRS - Computed Assisted Regional-Residual Separation
%
% auxiliary script to replicate figures in the paper
%
clear
load bgr.grd -ascii
load y0.grd -ascii
load x0.grd -ascii
load reg44.res -ascii
load reg55.res -ascii
load regLW.res -ascii
load par.res -ascii
load jfm.res -ascii
jFm=logical(jfm);
R0c=regLW;
gz=bgr+45.7;  
%
IY=[90 225 340 385 310];
nIY=4;
% Plotting parameters 
v=[0 0];
[nx ny]=size(gz);
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
cca=par(7);
N=nx*ny;
JF=reshape(jFm,N,1);
dc=reshape(gz ,N,1);
D0=dc(JF);
uu=reshape(repmat(x0,1,ny),N,1);
X0=uu(JF);
uu=reshape(repmat(y0',nx,1),N,1);
Y0=uu(JF);
n0=length(D0);
%
%-------------------Figure 8
siz=8;
figure
pcolor(y0',x0,gz);shading flat
axis image;caxis([-40 40])
axis([yI yF xI xF]);axis off
colormap jet
pause(3)
%print('gz_jet00', '-dtiff', '-r300');
%
%-------------------Figures 9abcde
siz=8;
figure
pcolor(y0',x0,gz);shading flat
hold on
plot(Y0(1:end),X0(1:end),'+k','MarkerSize',6)
for Iy=1:nIY
    iy=IY(Iy);
    jF=jFm(:,iy);
    plot([y0(iy) y0(iy)],[x0(1) x0(end)],'-k','LineWidth',1.0)
    wy=x0(jF);
    wx=0*wy+y0(iy);    
    plot(wx,wy,'ok','MarkerSize',siz,'MarkerFaceColor','y');
end
axis image;caxis([-40 40])
hold off;axis([yI yF xI xF]);axis off
colormap jet
pause(3)
%print('gz_jet01', '-dtiff', '-r300');
%
figure
pcolor(y0',x0,regLW);shading flat
axis image;caxis([-40 40]);hold on;
for Iy=1:nIY
    iy=IY(Iy);
    jF=jFm(:,iy);
    plot([y0(iy) y0(iy)],[x0(1) x0(end)],'-k','LineWidth',1.0)
    wy=x0(jF);
    wx=0*wy+y0(iy);    
    plot(wx,wy,'ok','MarkerSize',siz,'MarkerFaceColor','y');
end
hold off;axis([yI yF xI xF]);axis off;hold off
colormap jet
pause(3)
%print('gz_jet02', '-dtiff', '-r300');
%
%
figure
pcolor(y0',x0,regLW);shading flat
axis image;caxis([-40 40]);hold on;
for Iy=1:nIY
    iy=IY(Iy);
    jF=jFm(:,iy);
    plot([y0(iy) y0(iy)],[x0(1) x0(end)],'-k','LineWidth',1.0)
    wy=x0(jF);
    wx=0*wy+y0(iy);    
    plot(wx,wy,'ok','MarkerSize',siz,'MarkerFaceColor','y');
end
hold off;axis([yI yF xI xF]);axis off;hold off
colormap jet
pause(3)
%print('gz_jet02', '-dtiff', '-r300');
%
figure
pcolor(y0',x0,gz-regLW);shading flat
axis image;caxis([-40 40]);axis off
axis([yI yF xI xF]);colormap jet
pause(3)
%print('gz_jet_rsd_lowess', '-dtiff', '-r300');
%
%
% Modified FIGURE 9
figure
pcolor(y0',x0,reg55);
hold on;
for Iy=1:nIY
    iy=IY(Iy);
    jF=jFm(:,iy);
    plot([y0(iy) y0(iy)],[x0(1) x0(end)],'-k','LineWidth',1.0)
end
hold off;
shading flat
axis image;caxis([-40 40]);
axis([yI yF xI xF]);axis off;
colormap jet
pause(3)
%print('gz_jet04', '-dtiff', '-r300');
%
figure
pcolor(y0',x0,gz-reg55);
hold on;
for Iy=1:nIY
    iy=IY(Iy);
    jF=jFm(:,iy);
    plot([y0(iy) y0(iy)],[x0(1) x0(end)],'-k','LineWidth',1.0)
end
hold off;
shading flat
axis image;caxis([-40 40]);
axis([yI yF xI xF]);axis off;
colormap jet
pause(3)
%print('gz_jet05', '-dtiff', '-r300');
%
figure
pcolor(y0',x0,gz-reg55);
shading flat;axis image;caxis([-40 40]);
axis([yI yF xI xF]);axis off;
colormap jet
pause(3)
%print('gz_jet_rsd_55', '-dtiff', '-r300');
