% CARRS - Computed Assisted Regional-Residual Separation
%
% prog03 Interative choice for parameters eps_g and eps_c
% 
% input: grid data and derivatives from prog02
%
% output: selected points with low horizontal gradient and Laplacian
%         i.e.  Gh < eps_G & abs(Lh) < eps_L);
%         Gh horizontal gradient-intensity
%         Lh horizontal Laplacian
%
% obs:  threshold eps_G and eps_L set here will select points
%       at the flatter portions of the anomaly, in principle
%       representative of the regional field
%
%
%      Developed with:  
%      MATLAB 8.5 2015 version, 
%      64-bit Windows 11 PC (8 GB RAM, 2.80 GHz Intel Core processor)  
%--------------------------------------------------
%
clear
ioption=0;     % = 1 select your own eps_G and eps_L values
%
eps_G=0.2900;   % Gh cutoff as in the paper
eps_L=0.0101;  % Lh cutoff as in the paper
%
% a) data and derivative input
load bgr.grd -ascii
load y0.grd -ascii
load x0.grd -ascii
gz=bgr+45.7;
load gz1x.res -ascii
load gz1y.res -ascii
load gz2x.res -ascii
load gz2y.res -ascii
load par.res -ascii
%par=[sgm1 eps_g cc1 sgm2 eps_c cc2 cca dd eps_c cc3]';
cca=par(7);
[nx ny]=size(gz);
%
% b) Evaluate Laplacian Lh and horizontal gradient-intensity Gh
Lh=gz2x+gz2y;
Gh=sqrt(gz1x.*gz1x+gz1y.*gz1y);
save Gh.res Gh -ascii
save Lh.res Lh -ascii
%
% c) Reformat grided data to make histograms and set eps_G and eps_L 
N=nx*ny;
w1=reshape(Lh,1,nx*ny);w1=sort(abs(w1));
w2=reshape(Gh,1,nx*ny);w2=sort(abs(w2));
figure
subplot(121)
hist(log10(w2),12)
ax=axis;hold on;
axis square
plot(log10([eps_G eps_G]),ax(3:4),':k');
xlabel('Gradient (log mGal/km)')
ylabel('Number of cells')
if ioption==1
    [ao bo]=ginput(1);
    eps_G=10^ao;
    plot(log10([eps_G eps_G]),ax(3:4),'-r');
end
text(log10(eps_G),mean(ax(3:4)),['{\epsilon_G}=' num2str(eps_G,2)]);
hold off
subplot(122)
hist(log10(w1),[-5:0.5:1]);axis square
ax=axis;axis([-5 2 ax(3:4)]);
hold on;
xlabel('Laplacian (log mGal/km^2)')
ylabel('Number of cells')
plot(log10([eps_L eps_L]),ax(3:4),'k:');
if ioption == 1
    [ao bo]=ginput(1);
    eps_L=10^ao;
    plot(log10([eps_L eps_L]),ax(3:4),'-r');
end
text(log10(eps_L),mean(ax(3:4)),['{\epsilon_L}=' num2str(eps_L,2)]);
hold off
par(2)=eps_G;
par(9)=eps_L;
save par.res par -ascii
%
% d) selection of points with low Lh and Gh
jFm=NaN(nx,ny);
jFm =(abs(Gh) < eps_G & abs(Lh) < eps_L);
jfm=jFm*1;
save jfm.res jfm -ascii
%
% e) Picture of gz and the selected points with low Lh and Gh
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
figure
pcolor(y0',x0,gz)
colormap(mymap);shading flat;axis image
colorbar
hold on
for k=1:ny;
    jF=jFm(:,k);
    wy=x0(jF);
    wx=0*wy+y0(k);
    plot(wx,wy,'+k','MarkerSize',3);
end
hold off
caxis([-50 50]);
axis([yI yF xI xF])
title(['G_h < ' num2str(eps_G,2) ' AND L_h <' num2str(eps_L,2) ' N=' num2str(sum(sum((jFm))))])

