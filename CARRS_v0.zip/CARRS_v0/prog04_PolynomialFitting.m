% CARRS - Computed Assisted Regional-Residual Separation
%
% prog04 Polynomial fitting using function "fit"
% 
% input: list of the selected points with low Lh and Gh
%
% output: 
%   regional grids with poly44, poly55 and LOWESS [ROB-SELECTED POINTS]
%   regional grids with poly55, poly55-ROB [ALL POINTS]
%         
%    
% call function plot04.m to plot the regional-residual fields  
%
% obs:    the lowess parameter "span" is set here
%         lower values (0.1 for example) favouring local polynomial fitting
%         higher values (close o 1.0) providing global fitting
%
%         Developed with:  
%         MATLAB 8.5 2015 version, 
%         64-bit Windows 11 PC (8 GB RAM, 2.80 GHz Intel Core processor)  
%--------------------------------------------------
%
% a) set parameter span for the LOWESS fitting
clear
span=0.10;  
save spn.res span -ascii
%
% grid data input
load bgr.grd -ascii
load y0.grd -ascii
load x0.grd -ascii
gz=bgr+45.7;
[nx ny]=size(gz);
%
% b) Read the grid position of selected points with low gradient and
%    Laplacian
load jfm.res -ascii
jFm=logical(jfm);
%
% c) centering the data set - reshape the grid to a x,y,z table 
%    as required to call the fit-function
x0c=mean(x0);x0=x0-x0c;
y0c=mean(y0);y0=y0-y0c;
N=nx*ny;
JF=reshape(jFm,N,1);
D00=reshape(gz,N,1);n00=length(D00);
D0=D00(JF);n0=length(D0);
X00=reshape(repmat(x0,1,ny),N,1);
X0=X00(JF);
Y00=reshape(repmat(y0',nx,1),N,1);
Y0=Y00(JF);
%
% d)fucntion fit for poly44, poly55 and LOWESS [SELECTED POINTS] 
[xmesh, ymesh]=meshgrid(y0',x0);
A=fit([Y0,X0],D0,'poly44','robust','Bisquare','normalize','on');
R44 = feval(A,xmesh,ymesh);
save reg44.res R44 -ascii
A=fit([Y0,X0],D0,'poly55','robust','Bisquare','normalize','on');
R55 = feval(A,xmesh,ymesh);
save reg55.res R55 -ascii
tic
A=fit([Y0,X0],D0,'lowess','robust','Bisquare','normalize','on','Span',span);
RLW = feval(A,xmesh,ymesh);
disp('LOWESS robust polynomial fitting to selected CARRS points');toc
save regLW.res RLW -ascii
%
% e)funvtion fit for poly55, poly55-ROB [ALL POINTS] 
tic
A=fit([Y00,X00],D00,'poly55');
R55LSQ = feval(A,xmesh,ymesh);
disp('Conventional poly55 polynomial fitting to ALL points in the grid');toc
save reg55LSQ.res R55LSQ -ascii
% fit poly55-robusto to ALL data
tic
A=fit([Y00,X00],D00,'poly55','robust','Bisquare','normalize','on');
R55ROB = feval(A,xmesh,ymesh);
disp('Robust poly55 polynomial fitting to ALL points in the grid');toc
save reg55ROB.res R55ROB -ascii
%
% f) pictures for gz, the regional and residual fields
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
R0C=R55ROB;chtitle='poly55-ROB';plot04;pause(2)
R0C=R55LSQ;chtitle='poly55-LSQ';plot04;pause(2)
R0C=R44;chtitle='poly44-SEL-ROB';plot04;pause(2)
R0C=R55;chtitle='poly55-SEL-ROB';plot04;pause(2)
R0C=RLW;chtitle='LOWESS-SEL-ROB';plot04;


