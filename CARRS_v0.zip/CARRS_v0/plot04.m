% CARRS - Computed Assisted Regional-Residual Separation
%
% Auxiliary script to plot the outputs from prog04_PolynomialFitting
%
figure
subplot(131)
pcolor([y0'+y0c],[x0+x0c],gz);axis image;shading flat
axis([yI+y0c yF+y0c xI+x0c xF+x0c])
colormap(mymap);colorbar;title('Bouguer anomaly')
caxis([-40 40])
xlabel('(km)');ylabel('(km)')
subplot(132)
pcolor([y0'+y0c],[x0+x0c],R0C);axis image;shading flat
axis([yI+y0c yF+y0c xI+x0c xF+x0c]);title(['Regional ' chtitle])
colormap(mymap);colorbar
caxis([-40 40])
xlabel('(km)');ylabel('(km)')
subplot(133)
pcolor([y0'+y0c],[x0+x0c],gz-R0C);axis image;shading flat
axis([yI+y0c yF+y0c xI+x0c xF+x0c]);title(['Residual ' chtitle])
colormap(mymap);colorbar
hold on;contour([y0'+y0c],[x0+x0c],gz-R0C,[0 0],'-w');hold off
caxis([-40 40])
xlabel('(km)');ylabel('(km)')