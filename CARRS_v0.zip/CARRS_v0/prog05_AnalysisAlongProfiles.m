% CARRS - Computed Assisted Regional-Residual Separation
%
% prog05 Display the columns of the grid data with regionals from
%        poly55, poly55-ROB, poly55-SEL-ROB LOWESS-SEL-ROB
% 
% input: polynomial models from prog04
%
% output: column-along profiles showing the regional anomaly curves 
%         
%
% obs:    at this stage the interpreter is invited to evaluate if
%         regional fields from CARRS provides reliable representations
%         in terms of background geology or equivalent to common procedures 
%         applied in graphical separation methods 
%
%         Developed with:  
%         MATLAB 8.5 2015 version, 
%         64-bit Windows 11 PC (8 GB RAM, 2.80 GHz Intel Core processor)  
%--------------------------------------------------
%
% grid data input
clear
load bgr.grd -ascii
load y0.grd -ascii
load x0.grd -ascii
gz=bgr+45.7;
[nx ny]=size(gz);
%
% read output from progs 02 and 04
load jfm.res -ascii
jFm=logical(jfm);
load regLW.res -ascii
load reg55.res -ascii
load reg55ROB.res -ascii
load reg55LSQ.res -ascii
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
%
% profile display of the regional fields
n_step=10; % skip pace to showl column profiles
for iy=55:n_step:ny-55
    figure
    subplot(211)
    jF = jFm(:,iy);
    plot(x0,gz(:,iy),'-k','LineWidth',1.5);hold on
    plot(... 
        x0,reg55LSQ(:,iy),'--c',...
        x0,reg55ROB(:,iy),'-c',...
        x0,reg55(:,iy),'-g',...
        x0,regLW(:,iy),'-r','LineWidth',0.5);
    legend('real data','poly55','poly55-ROB','poly55-SEL-ROB','LOWESS-SEL-ROB');
    plot(x0(jF),gz(jF,iy),'ok','MarkerSize',6,'MarkerFaceColor','y');
    hold off
    axis([min(x0),max(x0),-40 50])
    title(['COLUMN ' num2str(iy)])
    subplot(224)
    pcolor(y0',x0,gz)
    colormap(mymap);shading flat;axis image;
    hold on
    plot([y0(iy) y0(iy)],[x0(1) x0(end)],'-k','LineWidth',1.0)
    for k=1:ny;
        kF=jFm(:,k);
        wy=x0(kF);
        wx=0*wy+y0(k);
        if k == iy
            plot(wx,wy,'ok','MarkerSize',6,'MarkerFaceColor','y');
        else
            plot(wx,wy,'+k','MarkerSize',2);
        end
    end
    caxis([-40 40])
    hold off
    pause(2)
end
