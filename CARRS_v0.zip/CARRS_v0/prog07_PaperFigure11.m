% CARRS - Computed Assisted Regional-Residual Separation
%
% auxiliary script to replicate figures in the paper
%
clear
load bgr.grd -ascii
load y0.grd -ascii
load x0.grd -ascii
load reg55.res -ascii
load reg55ROB.res -ascii
load reg55LSQ.res -ascii
load regLW.res -ascii
load par.res -ascii
load jfm.res -ascii
jFm=logical(jfm);
R0c=regLW;
gz=bgr+45.7;  
%
% Profiles P1-P4
IY=[90 225 340 385 310];
nIY=4;
% Plotting parameters 
v=[0 0];
[nx ny]=size(gz);
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
cca=par(7);
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
N=nx*ny;
JF=reshape(jFm,N,1);
dc=reshape(gz ,N,1);
D0=dc(JF);
uu=reshape(repmat(x0,1,ny),N,1);
X0=uu(JF);
uu=reshape(repmat(y0',nx,1),N,1);
Y0=uu(JF);
n0=length(D0);
%
% -----------------------------------------------Figure 11
figure
subplot(321)
iy=IY(1);
jF = jFm(:,iy);
plot(x0,gz(:,iy),'-k',x0,reg55LSQ(:,iy),'--c',x0,reg55ROB(:,iy),'-c',...
    x0,reg55(:,iy),'-g',...
    x0,regLW(:,iy),'-r','LineWidth',1.5);hold on
plot(x0(jF),gz(jF,iy),'ok','MarkerSize',6,'MarkerFaceColor','y');hold off
legend('data','poly55','poly55-ROB','poly55-SEL-ROB','LOWESS-SEL-ROB','selected points')
axis([xI xF -40 20]);text(15,-12,'P1')
xlabel(' Distance (km)')
ylabel('Gravity (mGal)')
%
subplot(322)
iy=IY(2);
jF = jFm(:,iy);
plot(x0,gz(:,iy),'-k',x0,reg55LSQ(:,iy),'--c',x0,reg55ROB(:,iy),'-c',...
    x0,reg55(:,iy),'-g',...
    x0,regLW(:,iy),'-r','LineWidth',1.5);hold on
plot(x0(jF),gz(jF,iy),'ok','MarkerSize',6,'MarkerFaceColor','y');hold off
axis([xI xF -20 20]);
text(15,-12,'P2')
xlabel(' Distance (km)')
ylabel('Gravity (mGal)')
%
subplot(323)
iy=IY(3);
jF = jFm(:,iy);
plot(x0,gz(:,iy),'-k',x0,reg55LSQ(:,iy),'--c',x0,reg55ROB(:,iy),'-c',...
    x0,reg55(:,iy),'-g',...
    x0,regLW(:,iy),'-r','LineWidth',1.5);
axis([xI xF -10 40]);hold on
plot(x0(jF),gz(jF,iy),'ok','MarkerSize',6,'MarkerFaceColor','y');hold off
text(15,-12,'P3')
xlabel(' Distance (km)')
ylabel('Gravity (mGal)')
%
subplot(324)
iy=IY(4);
jF = jFm(:,iy);
plot(x0,gz(:,iy),'-k',x0,reg55LSQ(:,iy),'--c',x0,reg55ROB(:,iy),'-c',...
    x0,reg55(:,iy),'-g',...
    x0,regLW(:,iy),'-r','LineWidth',1.5);hold on
plot(x0(jF),gz(jF,iy),'ok','MarkerSize',6,'MarkerFaceColor','y');hold off
axis([xI xF -25 55]);
text(15,-12,'P4')
xlabel(' Distance (km)')
ylabel('Gravity (mGal)')
