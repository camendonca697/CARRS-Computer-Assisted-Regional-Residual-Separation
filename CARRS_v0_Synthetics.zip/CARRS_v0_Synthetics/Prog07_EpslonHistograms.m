clear
m2km=1;
chp='-w';
load gz.res -ascii
load gz1.res -ascii
load gz2.res -ascii
load jFm.mat
load iFm.mat
load x0.res -ascii
load y0.res -ascii   
load pp.res -ascii
load par.res -ascii
%par=[sgm1 vCut1 cc1 sgm2 vCut_L cc2 cca dd vCurv cc3]';
vCut_G=par(2);
vCut_L=par(9);
cca=par(7); 
[nx ny]=size(gz);
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
%
%
% HISTOGRAMS FOR CHOSEN EPSLONS
figure
N=nx*ny;
w1=reshape(gz1,1,nx*ny);w1=sort(abs(w1));
w2=reshape(gz2,1,nx*ny);w2=sort(abs(w2));
subplot(221)
hist(log10(w1),10)
ax=axis;axis square
hold on;
plot(log10([vCut_G vCut_G]),ax(3:4),'-r');
text(log10(vCut_G),1100,['\epsilon_G=' num2str(vCut_G,2)]);
hold off
xlabel('H-Gradient (log mGal/km)')
ylabel('Data points')
subplot(222)
hist(log10(w2),10);
ax=axis;hold on;axis square
plot(log10([vCut_L vCut_L]),ax(3:4),'-r');
text(log10(vCut_L),1300,['\epsilon_L=' num2str(vCut_L,2)]);
hold off
xlabel('H-Laplacian (log mGal/km^{2})')
ylabel('Data points')
pause(2)
%
% MAPPED SELECTED POINTS
ch1='{G_h < }';
ch2='{|L_h|<=}';
figure
pcolor(y0'/m2km,x0/m2km,gz);
colormap(mymap);shading flat;axis image
colorbar
hold on
for k=1:ny;
    jF=jFm(:,k);
    wy=x0(jF);
    wx=0*wy+y0(k);
    plot(wx/m2km,wy/m2km,'+k','MarkerSize',3);
end
load ps.res -ascii
pp=ps;chp='-w';plota_prisma;
load pd.res -ascii
pp=pd;chp='-k';plota_prisma;
hold off
caxis([-cca cca]);axis([yI yF xI xF]/m2km)
title([ch1 num2str(vCut_G,2) ' AND ' ch2 num2str(vCut_L,2)])
xlabel('Y (km)');ylabel('X (km)')
%
%
