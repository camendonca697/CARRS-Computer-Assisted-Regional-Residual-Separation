clear
m2km=1;
load y0.res -ascii
load x0.res -ascii
load gz.res -ascii
load gzd.res -ascii
load gzv.res -ascii
load gz2.res -ascii
load jFm.mat
load iFm.mat
load reg44.res -ascii
load reg45.res -ascii
load reg55.res -ascii
load regLW.res -ascii 
load par.res -ascii
load pp.res -ascii
cca=120;
[nx ny]=size(gz);
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
%
% 1)
IY=[17 33 47 57 65 72];NY=length(IY);
msk=gz2*0;
R0C=regLW+msk;
chtitle='lowess';
%
%
figure
m2km=1;
cci=-50;%round(min(min(gz)));
ccf=+50;%round(max(max(gz)));
% TOP Figures
subplot(231)
pcolor(y0'/m2km,x0/m2km,gz);
colormap(mymap);shading flat;axis image
axis([yI yF xI xF]/m2km);
caxis([cci ccf])
%load pp.res -ascii
hold on;
load pd.res -ascii
pp=pd;chp='--k';plota_prisma;
load ps.res -ascii
pp=ps;chp='-w';plota_prisma;
hold off
ww=caxis;
xlabel('Y (km)');ylabel('X (km)')
a=colorbar;
% 
% Bottom Figure
subplot(234);
pcolor(y0'/m2km,x0/m2km,gz);
colormap(mymap);shading flat;axis image
a=colorbar;
hold on
for k=1:ny;
    jF=jFm(:,k);
    wy=x0(jF);
    wx=0*wy+y0(k);
    plot(wx/m2km,wy/m2km,'+k','MarkerSize',2);
end
for ii=1:NY-1
    k=IY(ii);
    jF=jFm(:,k);
    wy=x0(jF);
    wx=0*wy+y0(k);
    plot([y0(k) y0(k)],[x0(1) x0(end)],'-k','LineWidth',1.5);
    plot(wx/m2km,wy/m2km,'ok','MarkerSize',5,'MarkerFaceColor','y')
end
load ps.res -ascii
pp=ps;chp='-w';plota_prisma;
load pd.res -ascii
pp=pd;chp='--k';plota_prisma;
hold off
axis([yI yF xI xF]/m2km);caxis([cci ccf])
xlabel('Y (km)');ylabel('X (km)')
%

text(   61.2300,  346.7500,'p1')
text(  141.2400,  345.1200,'p2')
text(  206.5500,  346.7500,'p3')
text(  252.2700,  353.2800,'p4')
text(  293.0900,  353.2800,'p5')
