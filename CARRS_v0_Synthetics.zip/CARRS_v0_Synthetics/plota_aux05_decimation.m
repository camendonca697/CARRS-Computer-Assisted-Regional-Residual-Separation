figure
m2km=1;
cci=-50;%round(min(min(gz)));
ccf=+50;%round(max(max(gz)));
% TOP Figures
subplot(231)
pcolor(y0'/m2km,x0/m2km,gz);
axis image;shading flat
axis([yI yF xI xF]/m2km);
caxis([cci ccf])
%load pp.res -ascii
hold on;
load pd.res -ascii
pp=pd;chp='--k';plota_prisma;
load ps.res -ascii
pp=ps;chp='-w';plota_prisma;
hold off
colormap(mymap)
ww=caxis;
xlabel('Y (km)');ylabel('X (km)')
%
subplot(232)
pcolor(y0'/m2km,x0/m2km,R0C);
caxis(ww);axis image;shading flat
axis([yI yF xI xF]/m2km);caxis([cci ccf])
load pd.res -ascii
pp=pd;hold on;chp='--k';plota_prisma;hold off
colormap(mymap);
xlabel('Y (km)');ylabel('X (km)')
title([chtitle '-regional'])
%
subplot(233)
pcolor(y0'/m2km,x0/m2km,gz-R0C);axis image;shading flat
load ps.res -ascii
pp=ps;hold on;chp='-w';plota_prisma;hold off
hold on;chp='-w';plota_prisma;hold off
axis([yI yF xI xF]/m2km);caxis([cci ccf])
colormap(mymap)
xlabel('Y (km)');ylabel('X (km)')
title([chtitle '-residual'])
%
dcc=(ccf-cci)/20;
c1=[cci:dcc:-dcc]';
c2=[+dcc:dcc:ccf]';
cL=[c1;0;c2];cL=round(cL);
subplot(235)
[C ,h]=contour(y0'/m2km,x0/m2km,R0C,c1,'-b');set(h,'LineWidth',1.25)
hold on
[C ,h]=contour(y0'/m2km,x0/m2km,R0C,c2,'-r');set(h,'LineWidth',1.25)
%hold on;
[C, h]=contour(y0'/m2km,x0/m2km,gzd,cL,'-k');hold off
clabel(C,h,cL)
caxis(ww);axis image;
axis([yI yF xI xF]/m2km);
xlabel('Y (km)');ylabel('X (km)')
%
subplot(236)
dcc=(ccf-cci)/5;
c1=[cci:dcc:-dcc]';
c2=[+dcc:dcc:ccf]';cL=round([c1;0;c2]);
%[C ,h]=contour(y0'/m2km,x0/m2km,gz-R0C,round([c1;c2]),'-r');
[C ,h]=contour(y0'/m2km,x0/m2km,gz-R0C,round(c1),'-b');set(h,'LineWidth',1.25) 
hold on;
[C ,h]=contour(y0'/m2km,x0/m2km,gz-R0C,round(c2),'-r');set(h,'LineWidth',1.25) 
[C ,h]=contour(y0'/m2km,x0/m2km,gz-R0C,[-1.5 1.5],'-k');set(h,'LineWidth',0.15)
[C ,h]=contour(y0'/m2km,x0/m2km,gzv-gzd,cL,'-k');set(h,'LineWidth',1.0) 
clabel(C,h,cL)
hold off
caxis(ww);axis image;
axis([yI yF xI xF]/m2km);
xlabel('Y (km)');ylabel('X (km)')
%
subplot(234)
pcolor(y0'/m2km,x0/m2km,gz);
colormap(mymap);shading flat;axis image
colorbar
hold on
for k=1:ny;
    jF=jFm(:,k);
    wy=x0(jF);
    wx=0*wy+y0(k);
    plot(wx/m2km,wy/m2km,'+k','MarkerSize',1);
end
plota_prisma
hold off
caxis([-cca cca]);axis([yI yF xI xF]/m2km)
title(['skip pace = ' num2str(idec)])