clear
%
% THIS PROGRAM FIX NOISE-LEVELS FOR THE REGULARIZED DERIVATIVES:
% sgm1 for the 1st derivative, sgm2 for the 2nd derivative and shows
% results for derivatives evaluated directly from de model (gzv) and
% numerically evaluated under Tikhonov regularization and simple
% (non-regularized) central difference. 
% 
sgm1=1.0;
sgm2=0.001;
disp('Setting the regularization parameters')
%
% 1) Syntetic data input
m2km=1;
load gz.res -ascii
load gzv.res -ascii
load gzd.res -ascii
load x0.res -ascii
load y0.res -ascii   
load pp.res -ascii
load dd.res -ascii
dd=dd*m2km;
cca=max(max(gz))-min(min(gz));
par=[sgm1 0 0 sgm2 0 0 cca dd 0 0]';
save par.res par -ascii
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
%
% show grid rows (E-W)
nx=length(x0);
figure
for ix=10:5:nx-10
    aR1 = rdiff(gz(ix,:),dd,'tikhonov',sgm1);
    aR2 = rdiff(aR1,dd,'tikhonov',sgm2);
    aRv1=diff(gzv(ix,:))/dd;
    aRv2=diff(aRv1)/dd;aRv1=[aRv1 0];aRv2=[0 aRv2 0];
    aRn1=diff(gz(ix,:))/dd;
    aRn2=diff(aRn1)/dd;aRn1=[aRn1 0];aRn2=[0 aRn2 0];
    subplot(211)
    plot(y0/m2km,aRn2,'-c',y0/m2km,aRv2,'-k',y0/m2km,aR2,'-r');
    legend('non-regularized','true','regularized');
    title(['ROW - ' num2str(ix)])
    xlabel('(km)');
    ylabel('2nd derivative')
    subplot(212)
    plot(y0/m2km,aRn1,'-c',y0/m2km,aRv1,'-k',y0/m2km,aR1,'-r');
    xlabel('(km)');ylabel('1st derivative')
    pause(2)
end

