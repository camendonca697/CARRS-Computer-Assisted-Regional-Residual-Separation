clear
m2km=1;
load y0.res -ascii
load x0.res -ascii
load gz.res -ascii
load gzd.res -ascii
load gzv.res -ascii
load gz2.res -ascii
load jFm.mat
load iFm.mat
load reg33LSQ.res -ascii
load reg33ROB.res -ascii
load regLW.res -ascii 
load par.res -ascii
load pp.res -ascii
cca=120;
[nx ny]=size(gz);
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
%
%
msk=gz2*0;
% 1)verdadeiro
R0C=gzd+msk;
chtitle='true';
plota_aux055_AEditor
pause(1)
% 1)PLOTA LOWESS
R0C=regLW+msk;
chtitle='lowess';
plota_aux055_AEditor
pause(1)
%
% 1)33 robusto
R0C=reg33ROB+msk;
chtitle='33ROB';
plota_aux055_AEditor
pause(1)
%
% 1)33 LSQ
R0C=reg33LSQ+msk;
chtitle='33LSQ';
plota_aux055_AEditor
pause(1)
% 2) Profile plottings
IY=[17 33 47 57 65 72];NY=length(IY);
for ii=1:2:NY-1
    figure
    iy=IY(ii);
    subplot(321)
    MSK=msk(:,iy);
    jF = jFm(:,iy);
    plot(x0/m2km,gz(:,iy),'-k','LineWidth',2.0);
    ylabel('(mGal)')
    hold on
    plot(...
        x0/m2km,reg33LSQ(:,iy)+MSK,'--c',...
        x0/m2km,reg33ROB(:,iy)+MSK,'-c','LineWidth',1.5)
    plot(x0/m2km,regLW(:,iy)+MSK,'-g','LineWidth',2.0);
    plot(x0/m2km,gzd(:,iy),'-r','LineWidth',2.0)
    plot(x0(jF)/m2km,gz(jF,iy),'ok','MarkerSize',6,'MarkerFaceColor','y');
     if ii==1;legend('real data','poly33','poly33-ROB','LOWESS-SEL-ROB','true regional','selected points');end
    axis([x0(1)/m2km x0(end)/m2km -60 60])
    hold off
    text(10,-50,['Y=' num2str(y0(iy)/m2km) ' km'])
    %
    iy=IY(ii+1);
    subplot(323)
    MSK=msk(:,iy);
    jF = jFm(:,iy);
    plot(x0/m2km,gz(:,iy),'-k','LineWidth',2.0);
    ylabel('(mGal)')
    hold on
    plot(...
        x0/m2km,reg33LSQ(:,iy)+MSK,'--c',...
        x0/m2km,reg33ROB(:,iy)+MSK,'-c','LineWidth',1.5)
    plot(x0/m2km,regLW(:,iy)+MSK,'-g','LineWidth',2.0);
    plot(x0/m2km,gzd(:,iy),'-r','LineWidth',2.0)
    plot(x0(jF)/m2km,gz(jF,iy),'ok','MarkerSize',6,'MarkerFaceColor','y');
    axis([x0(1)/m2km x0(end)/m2km -60 60])
    hold off
    %title(['COLUMN ' num2str(iy) ' Y=' num2str(y0(iy)/m2km)])
    text(10,-50,['Y=' num2str(y0(iy)/m2km) ' km'])
    pause(1)
end
xlabel(' Distance (km)');
%
%
