clear
m2km=1e-3;
load y0.res -ascii
load x0.res -ascii
load gz.res -ascii
load gzd.res -ascii
load gzv.res -ascii
load gz2.res -ascii
[nx ny]=size(gz);
load reg44.res -ascii
load reg45.res -ascii
load reg55.res -ascii
load regLW.res -ascii 
load par.res -ascii
cca=par(7);
[nx ny]=size(gz);
%
clc
%chtitle=input([' Enter polyfit order (for example poly54 or lowess) ']);
chtitle='LOWESS';
%
% 1) Read selected points with low horizontal and 2nd z-derivatives
load jFm.mat
%
% 2) Mounting database x,y,gz 
x0c=mean(x0);x0=x0-x0c;
y0c=mean(y0);y0=y0-y0c;
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
%
% 1) Read selected points with low horizontal and 2nd z-derivatives
load jFm.mat
% 2) Mounting database x,y,gz 
N=nx*ny;
JF=reshape(jFm,N,1);
dc=reshape(gz,N,1);
D0=dc(JF);
uu=reshape(repmat(x0,1,ny),N,1);
X0=uu(JF);
uu=reshape(repmat(y0',nx,1),N,1);
Y0=uu(JF);
n0=length(D0);
%
% 3) Data fitting
[xmesh, ymesh]=meshgrid(y0',x0);
if chtitle == 'LOWESS'
    [A, gof] = fit([Y0,X0],D0,chtitle,'robust','Bisquare','normalize','on',...
        'Span',0.10);
else
    [A, gof] = fit([Y0,X0],D0,chtitle,'robust','Bisquare','normalize','on');
end
R55 = feval(A,xmesh,ymesh);
DC = feval(A,Y0,X0);
msk=gz2*0;
R0C=R55+msk;
%
% 4) Cross plot and R2
figure
subplot(121)
plot(D0,DC,'sk','MarkerFaceColor','w');
axis square
xlabel('Measured (mGal)')
ylabel('Evaluated (mGal)')
axis([-40 40 -40 40])
hold on;plot([-40 40],[-40 40],'-r','Linewidth',2);hold off
R2=gof.rsquare;
cR=num2str(0.01*round(100*R2));cR=['{R^2=}' cR];
text(-30,-30,cR);
title(['Model ' chtitle])
subplot(122)
hist(D0-DC,15);axis square
xlabel('Residuals (mGal)')
pause(3)
%
% 5) Results
figure
pcolor([y0'+y0c],[x0+x0c],gz);axis image;shading flat
axis([yI+y0c yF+y0c xI+x0c xF+x0c])
colormap(mymap);colorbar;title('Bouguer Anomaly')
caxis([-40 40])
xlabel('(km)');ylabel('(km)')
pause(2)
figure
pcolor([y0'+y0c],[x0+x0c],R0C);axis image;shading flat
axis([yI+y0c yF+y0c xI+x0c xF+x0c]);title(['Regional ' chtitle])
colormap(mymap);colorbar
caxis([-40 40])
xlabel('(km)');ylabel('(km)')
pause(2)
figure
pcolor([y0'+y0c],[x0+x0c],gz-R0C);axis image;shading flat
axis([yI+y0c yF+y0c xI+x0c xF+x0c]);title(['Residual ' chtitle])
colormap(mymap);colorbar
hold on;contour([y0'+y0c],[x0+x0c],gz-R0C,[0 0],'-w');hold off
caxis([-20 30])
xlabel('(km)');ylabel('(km)')
pause(2)
%
% COLUMN ALONG PROFILES
msk=gz2*0;
for iy=75:5:ny-55
    figure
    subplot(211)
    MSK=msk(:,iy);
    jF = jFm(:,iy);
    plot(x0,gz(:,iy),'-k','LineWidth',1.0);
    hold on
    plot(x0,R55(:,iy)+MSK,'-r','LineWidth',1.0);
    if iy==75;legend('real data',chtitle);end
    plot(x0(jF),gz(jF,iy),'ok','MarkerSize',6,'MarkerFaceColor','y');
    axis([min(x0),max(x0),-50 50])
    hold off
    title(['COLUMN ' num2str(iy)]);
    xlabel('X (km)');ylabel('Gravity (mGal)')
    text(-150,-40,['Y = ' num2str(y0(iy)) ' (km)'])
    subplot(224)
    pcolor(y0',x0,gz)
    colormap(mymap);shading flat;axis image;
    hold on
    plot([y0(iy) y0(iy)],[x0(1) x0(end)],'-k','LineWidth',1.0)
    for k=1:ny;
        kF=jFm(:,k);
        wy=x0(kF);
        wx=0*wy+y0(k);
        if k == iy
            plot(wx,wy,'ok','MarkerSize',4,'MarkerFaceColor','y');
        else
            plot(wx,wy,'+k','MarkerSize',1);
        end
    end
    caxis([-50 50])
    hold off
    pause(2)
end
