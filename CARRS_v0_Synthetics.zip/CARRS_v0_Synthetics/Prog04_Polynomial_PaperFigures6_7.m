clear
disp('Evaluating polynomial fitting poly45, poly55 and LOWESS')
m2km=1e-3;
load y0.res -ascii
load x0.res -ascii
load gz.res -ascii
load gzd.res -ascii
load gzv.res -ascii
load gz2.res -ascii
load par.res -ascii
load pp.res -ascii
load LSPAN.mat 
cca=par(7);
[nx ny]=size(gz);
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
%
% 1) Read selected points with low horizontal and 2nd z-derivatives
load iFm.mat
load jFm.mat
% 2) Mounting database x,y,gz 
N=nx*ny;
JF=reshape(jFm,N,1);
D00=reshape(gz ,N,1);n00=length(D00);
D0=D00(JF);n0=length(D0);
X00=reshape(repmat(x0,1,ny),N,1);
X0=X00(JF);
Y00=reshape(repmat(y0',nx,1),N,1);
Y0=Y00(JF);
%
[xmesh, ymesh]=meshgrid(y0',x0);
tic
A=fit([Y00,X00],D00,'poly33','robust','Bisquare','Normalize','on');
R33ROB = feval(A,xmesh,ymesh);
disp('Robust poly33 polynomial to ALL points');toc
save reg33rob.res R33ROB -ascii
%
tic
A=fit([Y00,X00],D00,'poly33');
R33LSQ = feval(A,xmesh,ymesh);
disp('Ordinary poly33 polynomial to ALL points');toc
save reg33LSQ.res R33LSQ -ascii
%
tic
A=fit([Y0,X0],D0,'lowess','robust','Bisquare','Normalize','on','Span',LSPAN);
RLW = feval(A,xmesh,ymesh);
disp('LOWESS polynomial fitting to selected points');toc
save regLW.res RLW -ascii
%
msk=gz2*0;
R0C=R33LSQ+msk;chtitle='poly33';plota_aux05;pause(2)
R0C=R33ROB+msk;chtitle='poly33-ROB';plota_aux05;pause(2)
R0C=RLW+msk;chtitle='LOWESS';plota_aux05;pause(3)
