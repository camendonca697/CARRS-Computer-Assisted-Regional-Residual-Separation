function v=plota_prismas(pp,hRef)
figure
np=length(pp(:,1));
for i=1:np
    alf=pp(i,10)*pi/180;
    calf=cos(alf);salf=sin(alf);Rot=[calf -salf;salf calf];
    vv=[-pp(i,3)/2 -pp(i,4)/2]';vv=Rot*vv;x1=pp(i,1)+vv(1);y1=pp(i,2)+vv(2);
    vv=[+pp(i,3)/2 -pp(i,4)/2]';vv=Rot*vv;x2=pp(i,1)+vv(1);y2=pp(i,2)+vv(2);
    vv=[+pp(i,3)/2 +pp(i,4)/2]';vv=Rot*vv;x3=pp(i,1)+vv(1);y3=pp(i,2)+vv(2);
    vv=[-pp(i,3)/2 +pp(i,4)/2]';vv=Rot*vv;x4=pp(i,1)+vv(1);y4=pp(i,2)+vv(2);
    z0=-pp(i,5); z1=-pp(i,6);
    Mag=pp(i,7);
    vertex=[...
        x1 y1 z0;
        x2 y2 z0;
        x3 y3 z0;
        x4 y4 z0;
        x1 y1 z1;
        x2 y2 z1;
        x3 y3 z1;
        x4 y4 z1];
    face=[...
        1 2 3 4;
        1 5 8 4;
        4 8 7 3;
        3 7 6 2;
        2 6 5 1;
        5 6 7 8];
    cor=repmat(0.9*[1 1 1],6,1);if pp(i,11)<0;cor=repmat(0.5*[1 1 1],6,1);
    end
patch('Vertices',vertex,'Faces',face,'FaceVertexCData',cor,'FaceColor','flat')
text(pp(i,1),pp(i,2),-pp(i,5)+1.5,num2str(i));
end
view(-30,10);
axis image
axis ij
grid on
xlabel('X (km)');ylabel('Y (km)');zlabel('Z (km)')
v=1;
return
%
%
function V=rgb_scl(v,Vmin,Vmax) 
n=length(v);
vd=mean(diff(v));
if vd==0
    V=repmat([0 0 1],n,1);
else
    V=zeros(n,3);
    vi=Vmin;
    vf=Vmax;
    zc=v-min(v);
    zc=zc./max(zc);
    for i=1:n
        iN=isnan(zc(i));
        if iN
            V(i,1:3)=[1 1 1];
        else
            if zc(i)>=0.0 & zc(i)<0.2;vi=[1 0 1];vf=[0 0 1];cz=5*[zc(i)-0.0];end % magenta-blue
            if zc(i)>=0.2 & zc(i)<0.4;vi=[0 0 1];vf=[0 1 1];cz=5*[zc(i)-0.2];end % blue-cyan
            if zc(i)>=0.4 & zc(i)<0.6;vi=[0 1 1];vf=[0 1 0];cz=5*[zc(i)-0.4];end % cyan-green
            if zc(i)>=0.6 & zc(i)<0.8;vi=[0 1 0];vf=[1 1 0];cz=5*[zc(i)-0.6];end % green-yellow
            if zc(i)>=0.8 & zc(i)<=1.;vi=[1 1 0];vf=[1 0 0];cz=5*[zc(i)-0.8];end % yellow-red
            V(i,1:3)=cz*vf+[1-cz]*vi;
        end
    end 
end

