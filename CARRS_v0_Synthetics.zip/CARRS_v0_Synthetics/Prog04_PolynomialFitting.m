clear
disp('Evaluating polynomial fitting poly45, poly55 and LOWESS')
m2km=1e-3;
load y0.res -ascii
load x0.res -ascii
load gz.res -ascii
load gzd.res -ascii
load gzv.res -ascii
load gz2.res -ascii
load par.res -ascii
load pp.res -ascii
load LSPAN.mat 
cca=par(7);
[nx ny]=size(gz);
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
%
% 1) Read selected points with low horizontal and 2nd z-derivatives
load iFm.mat
load jFm.mat
% 2) Mounting database x,y,gz 
N=nx*ny;
JF=reshape(jFm,N,1);
dc=reshape(gz ,N,1);
D0=dc(JF);
uu=reshape(repmat(x0,1,ny),N,1);
X0=uu(JF);
uu=reshape(repmat(y0',nx,1),N,1);
Y0=uu(JF);
n0=length(D0);
%
[xmesh, ymesh]=meshgrid(y0',x0);
A=fit([Y0,X0],D0,'poly44','robust','Bisquare','Normalize','on');
R44 = feval(A,xmesh,ymesh);
save reg44.res R44 -ascii
A=fit([Y0,X0],D0,'poly45','robust','Bisquare','Normalize','on');
R45 = feval(A,xmesh,ymesh);
save reg45.res R45 -ascii
A=fit([Y0,X0],D0,'poly55','robust','Bisquare','Normalize','on');
R55 = feval(A,xmesh,ymesh);
save reg55.res R55 -ascii
%
%
A=fit([Y0,X0],D0,'lowess','robust','Bisquare','Normalize','on','Span',LSPAN);
RLW = feval(A,xmesh,ymesh);
save regLW.res RLW -ascii
%
msk=gz2*0;
R0C=R45+msk;chtitle='poly45';plota_aux05;pause(2)
R0C=R55+msk;chtitle='poly55';plota_aux05;pause(2)
R0C=RLW+msk;chtitle='LOWESS';plota_aux05;pause(3)
