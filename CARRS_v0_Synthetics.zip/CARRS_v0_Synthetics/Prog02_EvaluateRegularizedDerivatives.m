clear
disp('Evaluating column-and-row derivatives')
m2km=1;
load gz.res -ascii
load x0.res -ascii
load y0.res -ascii   
load par.res -ascii
%par=[sgm1 vCut1 cc1 sgm2 vCut2 cc2 cca dd vCurv cc3]';
sgm1=par(1);
sgm2=par(4);
dd=par(8);
%
xI=x0(1);xF=x0(end);
yI=y0(1);yF=y0(end);
[nx ny]=size(gz);
Gz1=zeros(nx,ny);
Gz2=zeros(nx,ny);
tic
disp('derivatives along grid columns _____')
for iy=1:ny
    jNaN=not(isnan(gz(:,iy)));
    aR1 = rdiff(gz(jNaN,iy),dd*m2km,'tikhonov');
    aR2 = rdiff(aR1,dd*m2km,'tikhonov');
    Crv=aR2./([1+aR1.^2].^3/2);
    aFn=nan(nx,1);aFn(jNaN)=aR1';aR1=aFn;
    aFn=nan(nx,1);aFn(jNaN)=aR2';aR2=aFn;
    Gz1(:,iy)=aR1;
    Gz2(:,iy)=aR2;
     fp=10;ff=floor(ny*fp/100);rg=rem(iy,ff);
    if rg == 0;disp(['----' num2str(iy/ff*fp)]);end
end
save gz1x.res Gz1 -ascii 
save gz2x.res Gz2 -ascii
toc
%
%
disp('derivatives along grid rows______')
tic
Gz1=zeros(nx,ny);
Gz2=zeros(nx,ny);
for ix=1:nx
    jNaN=not(isnan(gz(ix,:)));
    aR1 = rdiff(gz(ix,jNaN),dd*m2km,'tikhonov');
    aR2 = rdiff(aR1,dd*m2km,'tikhonov');
    Crv=aR2./([1+aR1.^2].^3/2);
    aFn=nan(ny,1);aFn(jNaN)=aR1;aR1=aFn;
    aFn=nan(ny,1);aFn(jNaN)=aR2;aR2=aFn;
    Gz1(ix,:)=aR1;
    Gz2(ix,:)=aR2;   
    fp=10;ff=floor(nx*fp/100);rg=rem(ix,ff);
    if rg == 0;disp(['----' num2str(ix/ff*fp)]);end
end
save gz1y.res Gz1 -ascii
save gz2y.res Gz2 -ascii
toc