function [ftt,ftx,fty,ftz,fgz,fzx,fzy,fzz]=multi_prism(pp)
global x0 y0 z0 nx ny v
% x0 N-S grid vector
% y0 E-W grid vector
% z0 elevation 
% v=[INC DEC] local geomagnetic field inclination and declination (degree)
%
% based on
% https://doi.org/10.1016/j.cageo.2011.02.008
% https://doi.org/10.1016/j.cageo.2007.09.013
%
np=length(pp(:,1));
ftt=zeros(nx,ny);
ftx=ftt;
fty=ftt;  
ftz=ftt;
fgz=ftt;
fgx=ftt;
fzx=ftt;
fzy=ftt;
fzz=ftt;
for i = 1 : np
    p=pp(i,1:11);
    [o1,o2,o3,o4,o5,o6,o7,o8]=one_prism(x0,y0,z0,nx,ny,v,p);
    ftt=ftt+o1;
    ftx=ftx+o2;
    fty=fty+o3;
    ftz=ftz+o4;
    fgz=fgz+o5;
    fzx=fzx+o6;
    fzy=fzy+o7;
    fzz=fzz+o8;
end
return
%
%
function [ftt,ftx,fty,ftz,fgz,fzx,fzy,fzz]=one_prism(x0,y0,z0,nx,ny,v,p)	
fac = 0.0174532925;
cgg = 6.67;
cmm = 100;
xc=p(1);
yc=p(2);
x1=xc-p(3)/2;
x2=xc+p(3)/2;
y1=yc-p(4)/2;
y2=yc+p(4)/2;
z1=p(5);
z2=p(6);
smag=p(7)*cmm;
sinc=p(8)*fac;
sdec=p(9)*fac;
teta=p(10)*fac;
dns=p(11)*cgg;
finc=v(1)*fac;
fdec=v(2)*fac;
%  direction cosines
cm1=cos(sinc)*cos(sdec-teta);
cm2=cos(sinc)*sin(sdec-teta);
cm3=sin(sinc);
cf1=cos(finc)*cos(fdec-teta);
cf2=cos(finc)*sin(fdec-teta);
cf3=sin(finc);
f1t=cm2*cf3+cm3*cf2;
f2t=cm1*cf3+cm3*cf1;
f3t=cm1*cf2+cm2*cf1;
f4t=cm1*cf1;
f5t=cm2*cf2;
f6t=cm3*cf3;
% x-component 
cf1x=cos(-teta);
cf2x=sin(-teta);
f1x=cm3*cf2x;
f2x=cm3*cf1x;
f3x=cm1*cf2x+cm2*cf1x;
f4x=cm1*cf1x;
f5x=cm2*cf2x;
% y-component 
cf1y=cos(90*fac-teta);
cf2y=sin(90*fac-teta);
f1y=cm3*cf2y;
f2y=cm3*cf1y;
f3y=cm1*cf2y+cm2*cf1y;
f4y=cm1*cf1y;
f5y=cm2*cf2y;
% z-component 
f1z=cm2;
f2z=cm1;
f6z=cm3;
% frame rotation
cteta=cos(teta);
steta=sin(teta);
for iy = 1 : ny
    for ix = 1 : nx
        xb=xc+cteta*(x0(ix)-xc)+steta*(y0(iy)-yc);
        yb=yc-steta*(x0(ix)-xc)+cteta*(y0(iy)-yc);
        zb=z0(ix,iy);
        xx(1)=xb-x1;
        xx(2)=xb-x2;
        yy(1)=yb-y1;
        yy(2)=yb-y2;
        zz(1)=zb-z1;
        zz(2)=zb-z2;
        isgn(1)=-1;
        isgn(2)=+1;
        tt=0;
        tx=0;
        ty=0;
        tz=0;
        gz=0;
        gzx=0;
        gzy=0;
        gzz=0;
        for k=1:2
            for j =1:2
                for i =1:2
                    r2=xx(i).*xx(i)+yy(j).*yy(j)+zz(k).*zz(k);
                    ijk=isgn(i)*isgn(j)*isgn(k);
                    rr=sqrt(r2);
                    ag1=0.5*log((rr-xx(i))/(rr+xx(i)));
                    ag2=0.5*log((rr-yy(j))/(rr+yy(j)));
                    ag3=0.5*log((rr-zz(k))/(rr+zz(k)));
                    ag4=atan((yy(j)*zz(k))/(xx(i)*rr));
                    ag5=atan((xx(i)*zz(k))/(yy(j)*rr));
                    ag6=atan((xx(i)*yy(j))/(zz(k)*rr));
                    % magnetic field components
                    tt=tt+ijk*(f1t*ag1+f2t*ag2+f3t*ag3+f4t*ag4+f5t*ag5+f6t*ag6);
                    tx=tx+ijk*(f1x*ag1+f2x*ag2+f3x*ag3+f4x*ag4+f5x*ag5);
                    ty=ty+ijk*(f1y*ag1+f2y*ag2+f3y*ag3+f4y*ag4+f5y*ag5);
                    tz=tz+ijk*(f1z*ag1+f2z*ag2+f6z*ag6);
                    % gravity fields components
                    gz=gz+ijk*(xx(i)*ag2+yy(j)*ag1+zz(k)*ag6);
                    gzx=gzx+ijk*(cf1x*ag2+cf2x*ag1);
                    gzy=gzy+ijk*(cf1y*ag2+cf2y*ag1);
                    gzz=gzz+ijk*ag6;
                end
            end
        end
        ftt(ix,iy)=tt*smag;
        ftx(ix,iy)=tx*smag;
        fty(ix,iy)=ty*smag;
        ftz(ix,iy)=tz*smag;
        fgz(ix,iy)=gz*dns;
        fzx(ix,iy)=gzx*dns;
        fzy(ix,iy)=gzy*dns;
        fzz(ix,iy)=gzz*dns;
    end
end