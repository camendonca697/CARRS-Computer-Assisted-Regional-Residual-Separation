margins = [7 7 15 11]; % N S E W
A = imread('aaa.png');
A = A(1+margins(1):end-margins(2),1+margins(4):end-margins(3),:);
CT0 = permute(mean(im2double(A),1),[2 3 1]);
CT0 = CT0([true; ~all(diff(CT0,1,1)==0,2)],:); % remove duplicate rows
% CT0 is now a fixed-length color table
% make it whatever length we want
N = 32; % specify the number of colors in table
na = size(CT0,1);
CT = interp1(linspace(0,1,na),CT0,linspace(0,1,N));
colormap(CT)
