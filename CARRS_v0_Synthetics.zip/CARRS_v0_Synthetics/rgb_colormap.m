function V=rgb_colormap(v,Vmin,Vmax) 
n=length(v);
% blue-cyan-green-yellow-red-magenta-white
Vc=[0 0 0.5;...
    0 0 1;...
    0 1 1;...
    0 1 0;...
    1 1 0;...
    1 0 0;...
    1 0 1;...
    1 1 1];
Nc=length(Vc(:,1))-1;
vv=linspace(0,1,Nc+1);
V=zeros(n,3);
vi=Vmin;
vf=Vmax;
zc=v-min(v);
zc=zc./max(zc);
for i=1:n
    for k=1:Nc
        if zc(i)>=vv(k) & zc(i)<vv(k+1);
            vi=Vc(k,:);
            vf=Vc(k+1,:);
            cz=[zc(i)-vv(k)]/(vv(k+1)-vv(k));
        end
        V(i,1:3)=cz*vf+[1-cz]*vi;
    end
end