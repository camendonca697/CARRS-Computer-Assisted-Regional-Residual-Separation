%
%--------------------------------------------------------------
clear
global x0 y0 z0 nx ny v
%
%
sgm=1.0; % noise level
%
%
% 1) Data window and grid parameters
dd=4.75;
xi=0;xf=328.5;
yi=0;yf=368.25;
dx=dd;dy=dd;
x0=[xi:dx:xf]';nx=length(x0);
y0=[yi:dy:yf]';ny=length(y0);
zo=-0.2; % height of measurements, negative upward
z0=zo*ones(nx,ny);
v=[-6 10];
%
% 3) Model parameters
hRef=35;
dF=2.0;dRo=0.3;
% pp=[1xc 2yc 3Lx 4Ly 5zt      6zb     7MAG   8inc 9dec     10alfa 11dens
%250 300  50 100  hRef-dF  hRef    0.35   v(1)  v(2)    30  dRo;...
% Crustal middle interface effects
pD=[...
      180 250 250 100  hRef-dF  hRef    0.35   v(1)  v(2)    30   dRo;...
      150 100 250 100  hRef    hRef+dF  0.35   v(1)  v(2)    30  -dRo]; 
[ftt,ftx,fty,ftz,GzD,fzx,fzy,fzz]=multi_prism(pD);
% Shallow sources
dRoFe=0.2;
dRo1=0.3;
dRoGrnt=-0.2;
   pS=[...
      50  75  30 30  2.0  7    0.35   v(1)  v(2)     0   +dRo1;...
      50 225  30 30  2.0  7    0.35   v(1)  v(2)     0   +dRo1;...
     150  75  30 30  2.0  7    0.35   v(1)  v(2)     0   -dRo1;...
     150 225  30 30  2.0  7    0.35   v(1)  v(2)     0   -dRo1;...
     250  75  30 30  2.0  7    0.35   v(1)  v(2)     0   +dRo1;...
     250 225  30 30  2.0  7    0.35   v(1)  v(2)     0   -dRo1];
  %...     230 220  15 120 2.0  7    0.35   v(1)  v(2)    30   dRoFe;...
[ftt,ftx,fty,ftz,GzS,fzx,fzy,fzz]=multi_prism(pS);      
GzV=GzD+GzS;      
pp=[pD;pS];
%
% 4) noise
Gz=GzV+randn(nx,ny)*sgm;
%
% 5) pictures
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
figure
pcolor(y0',x0,Gz);
colormap(mymap);colorbar
shading flat;
axis image;ww=axis;
xlabel('Y (km)');
ylabel('X (km)');
hold on
chp='-w';plota_prisma;axis(ww)
hold off
%
%
save gzv.res GzV -ascii
save gzs.res GzS -ascii
save gzd.res GzD -ascii
save gz.res Gz -ascii
save x0.res x0 -ascii
save y0.res y0 -ascii
save pp.res pp -ascii
save pd.res pD -ascii
save ps.res pS -ascii
save dd.res dd -ascii
%
plota_prismas(pp,hRef);
axis square
view(-56,26)
axis([yi yf xi xf -(hRef+dF) 0])
