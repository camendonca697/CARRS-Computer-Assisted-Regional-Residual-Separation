clear
m2km=1;
disp('Showing results along selected grid columns')
load y0.res -ascii
load x0.res -ascii
load gz.res -ascii
load gzd.res -ascii
load gzv.res -ascii
load gz2.res -ascii
load iFm.mat
load jFm.mat
[nx ny]=size(gz);
load reg44.res -ascii
load reg45.res -ascii
load reg55.res -ascii
load regLW.res -ascii 
load par.res -ascii
cca=par(7);
%
% Plotting fields along selected profiles
msk=gz2*0;
for iy=5:4:ny-5
    figure
    subplot(211)
    MSK=msk(:,iy);
    iF = iFm(:,iy);jF = jFm(:,iy);
    plot(x0/m2km,gz(:,iy),'-k','LineWidth',1.5);
    xlabel(' X (km)')
    ylabel('(mGal)')
    hold on
    plot(...
        x0/m2km,reg44(:,iy)+MSK,'--c',...
        x0/m2km,reg45(:,iy)+MSK,'-.c',...
        x0/m2km,reg55(:,iy)+MSK,'-c','LineWidth',0.5)
    plot(x0/m2km,regLW(:,iy)+MSK,'-g','LineWidth',1.5);
    plot(x0/m2km,gzd(:,iy),'-r','LineWidth',1.5)
    legend('real data','poly44','poly45','poly55','lowess','true regional')
    plot(x0(jF)/m2km,gz(jF,iy),'ok','MarkerSize',5,'MarkerFaceColor','y');
    axis([x0(1)/m2km x0(end)/m2km -cca/2 cca/2])
    hold off
    title(['column - ' num2str(iy)])
    pause(2)
end



