%
%--------------------------------------------------------------
clear
global x0 y0 z0 nx ny v
v=[-6 10];
%
% 1) Data window and grid parameters
dd=4.75;
xi=0;xf=328.5;
yi=0;yf=368.25;
dx=dd;dy=dd;
x0=[xi:dx:xf]';nx=length(x0);
y0=[yi:dy:yf]';ny=length(y0);
zo=-0.2; % height of measurements, negative upward
z0=zo*ones(nx,ny);
% 3) Model parameters
hRef=35;
dF=2.5;dRo=0.5;
% pp=[1xc 2yc 3Lx 4Ly 5zt      6zb     7MAG   8inc 9dec     10alfa 11dens
%250 300  50 100  hRef-dF  hRef    0.35   v(1)  v(2)    30  dRo;...
% Crustal middle interface effects
pD=[...
      280 230  50 50  hRef-dF  hRef    0.35   v(1)  v(2)     0   dRo;...
      260 280  50 50  hRef-dF  hRef    0.35   v(1)  v(2)     0   dRo;...
      230 330  50 50  hRef-dF  hRef    0.35   v(1)  v(2)     0   dRo;...
      200  70  70 100  hRef    hRef+dF  0.35   v(1)  v(2)     0  -dRo;...
      120  95  90  50  hRef    hRef+dF  0.35   v(1)  v(2)     0  -dRo;...
       50  325 60  40  hRef    hRef+dF  0.35   v(1)  v(2)     0  -dRo]; 
[ftt,ftx,fty,ftz,GzD,fzx,fzy,fzz]=multi_prism(pD);
% Shallow sources
dRoFe=0.2;
dRo1=0.3;
dRoGrnt=-0.2;
   pS=[...  
     120 300  30 30  1.0  5    0.35   v(1)  v(2)     0   dRoGrnt;...
     100 180  30 30  1.0  5    0.35   v(1)  v(2)     0   dRoGrnt;...  
     190 220  15 120 1.0  5    0.35   v(1)  v(2)    30   dRoFe;...
     110 225  25 25  1.0  5    0.35   v(1)  v(2)     0   dRo1;...
      60 225  25 25  1.0  5    0.35   v(1)  v(2)     0   dRo1;...
      30 190  25 25  1.0  5    0.35   v(1)  v(2)     0   dRo1];%...
[ftt,ftx,fty,ftz,GzS,fzx,fzy,fzz]=multi_prism(pS);      
GzV=GzD+GzS;      
pp=[pD;pS];
%
% 4) noise
sgm=0.5;
Gz=GzV+randn(nx,ny)*sgm;
%
% 5) pictures
mymap=rgb_colormap(0.0:0.05:1.00,0,1);
figure
pcolor(y0',x0,Gz);
colormap(mymap);colorbar
shading flat;
axis image;ww=axis;
xlabel('Y (km)');
ylabel('X (km)');
hold on
chp='-k';
plota_prisma;axis(ww)
hold off
%
%
save gzv.res GzV -ascii
save gzs.res GzS -ascii
save gzd.res GzD -ascii
save gz.res Gz -ascii
save x0.res x0 -ascii
save y0.res y0 -ascii
save pp.res pp -ascii
save pd.res pD -ascii
save ps.res pS -ascii
save dd.res dd -ascii
%
plota_prismas(pp,hRef);
axis square
view(-56,26)
axis([yi yf xi xf -(hRef+dF) 0])
