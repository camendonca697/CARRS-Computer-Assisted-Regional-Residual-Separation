np=length(pp(:,1));
for i=1:np
    alf=pp(i,10)*pi/180;
    calf=cos(alf);
    salf=sin(alf);
    Rot=[calf -salf;salf calf];
    vv=[-pp(i,3)/2 -pp(i,4)/2]';vv=Rot*vv;x1=pp(i,1)+vv(1);y1=pp(i,2)+vv(2);
    vv=[+pp(i,3)/2 -pp(i,4)/2]';vv=Rot*vv;x2=pp(i,1)+vv(1);y2=pp(i,2)+vv(2);
    vv=[+pp(i,3)/2 +pp(i,4)/2]';vv=Rot*vv;x3=pp(i,1)+vv(1);y3=pp(i,2)+vv(2);
    vv=[-pp(i,3)/2 +pp(i,4)/2]';vv=Rot*vv;x4=pp(i,1)+vv(1);y4=pp(i,2)+vv(2);
    h=plot([y1 y2 y3 y4 y1],[x1 x2 x3 x4 x1],chp);
    set(h,'LineWidth',0.5)
end